import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import calendar

# ========== Data Loading and Preparation ========== #
@st.cache_data
def load_data():
    """
    Load and preprocess datasets.
    """
    listings = pd.read_csv('data/listings.csv')
    neighbourhoods = pd.read_csv('data/neighbourhoods.csv')
    reviews = pd.read_csv('data/reviews.csv')

    # Merge datasets
    listings = listings.merge(neighbourhoods, on='neighbourhood', how='left')

    # Handle missing values
    listings.fillna({'reviews_per_month': 0, 'license': 'Unknown'}, inplace=True)
    listings.dropna(subset=['price'], inplace=True)

    # Convert date columns
    listings['last_review'] = pd.to_datetime(listings['last_review'])
    reviews['date'] = pd.to_datetime(reviews['date'])

    # Add year and month columns for reviews
    reviews['year'] = reviews['date'].dt.year
    reviews['month'] = reviews['date'].dt.month

    return listings, reviews

# Load data
listings, reviews = load_data()

# ========== Analysis Functions ========== #
def average_prices(data, neighborhood, room_type=None):
    """
    Calculate average prices for listings in a neighborhood, optionally filtering by room type.
    """
    filtered = data[data['neighbourhood'] == neighborhood]
    if room_type:
        filtered = filtered[filtered['room_type'] == room_type]
    return filtered.groupby('room_type')['price'].mean()

def availability_trends(data, neighborhood):
    """
    Calculate availability trends by month for a specific neighborhood.
    """
    filtered = data[data['neighbourhood'] == neighborhood]
    return filtered.groupby(filtered['last_review'].dt.month)['availability_365'].mean()

def affordable_listings(data, max_price):
    """
    Get listings that are below or equal to a specific maximum price.
    """
    return data[data['price'] <= max_price]

def render_filter_by_reviews():
    st.header("Filter Listings by Number of Reviews")
    st.markdown("""
    **Description:**  
    Use the slider below to filter listings based on the minimum number of reviews.  
    This allows you to focus on more established listings, which may have higher ratings and more customer feedback.
    """)

    # Slider for minimum number of reviews
    min_reviews = st.slider(
        "Select Minimum Number of Reviews", 
        0, 1000, 50,  # Slider range from 0 to 1000, default is 50
        step=10, 
        help="Select the minimum number of reviews for the listings you want to view."
    )

    # Filter listings based on the selected minimum reviews
    filtered_listings = listings[listings['number_of_reviews'] >= min_reviews]

    # Display the filtered listings
    if not filtered_listings.empty:
        st.subheader(f"Listings with at least {min_reviews} reviews")
        
        # Display a summary of the filtered data (e.g., count of listings)
        st.markdown(f"Total Listings: {len(filtered_listings)}")
        
        # Show the filtered listings on a map (if applicable)
        st.markdown("### Listings on the Map")
        import pydeck as pdk

        # Create the map using filtered listings
        map_data = filtered_listings[['latitude', 'longitude', 'name', 'price']]
        deck = pdk.Deck(
            map_style="mapbox://styles/mapbox/light-v10",
            initial_view_state=pdk.ViewState(
                latitude=filtered_listings['latitude'].mean(),
                longitude=filtered_listings['longitude'].mean(),
                zoom=12,
                pitch=50,
            ),
            layers=[
                pdk.Layer(
                    'ScatterplotLayer',
                    data=map_data,
                    get_position='[longitude, latitude]',
                    get_color='[200, 30, 0, 160]',
                    get_radius=100,
                    pickable=True,
                    auto_highlight=True,
                ),
                pdk.Layer(
                    'TextLayer',
                    data=map_data,
                    get_position='[longitude, latitude]',
                    get_text='name',
                    get_size=12,
                    get_color=[0, 0, 0],
                    get_alignment_baseline='bottom',
                ),
            ],
            tooltip={
                "html": "<b>Listing:</b> {name}<br><b>Price:</b> ${price}<br><b>Reviews:</b> {number_of_reviews}",
                "style": {"backgroundColor": "steelblue", "color": "white"},
            },
        )

        st.pydeck_chart(deck)

        # Display the filtered listings in a table
        st.subheader("Detailed Listings Table")
        st.markdown("""
        The table below shows detailed information about the listings that meet the review criteria.
        """)
        st.dataframe(filtered_listings[['name', 'room_type', 'price', 'number_of_reviews', 'availability_365']])
    else:
        st.info(f"No listings found with at least {min_reviews} reviews.")

def summary_statistics(data, neighborhood):
    """
    Generate summary statistics for listings in a specific neighborhood.
    """
    filtered = data[data['neighbourhood'] == neighborhood]
    return filtered[['price', 'availability_365']].describe()

# ========== Streamlit App ========== #
def app_title():
    st.title("Boston Airbnb Data Explorer")
    st.markdown("""
    **Welcome to the Boston Airbnb Data Explorer!**  
    This interactive application allows you to explore Airbnb listings in Boston with engaging visualizations and user-friendly tools. Use the sidebar to navigate through different features and uncover insights into rental prices, availability trends, and affordable listings.  
    """)

def render_average_prices():
    st.header("Average Rental Prices")
    st.markdown("""
    **Description:**  
    Use the filters below to explore the average rental prices for Airbnb listings in Boston.  
    - Select a neighborhood to focus on a specific area.  
    - Optionally, filter by room type for more precise analysis.  
    - The chart dynamically updates based on your selections, and the data table below provides detailed insights.
    """)

    # Sidebar Filters
    col1, col2 = st.columns([1, 1])

    with col1:
        neighborhood = st.selectbox(
            "Select Neighborhood", 
            listings['neighbourhood'].unique(), 
            help="Choose a neighborhood to analyze average rental prices."
        )
    
    with col2:
        room_type = st.selectbox(
            "Select Room Type (Optional)", 
            ["All"] + list(listings['room_type'].unique()), 
            help="Filter by room type (e.g., Entire home/apt, Private room)."
        )

    # Filter Data
    filtered_data = listings[listings['neighbourhood'] == neighborhood]
    if room_type != "All":
        filtered_data = filtered_data[filtered_data['room_type'] == room_type]

    # Calculate Averages
    avg_prices = filtered_data.groupby('room_type')['price'].mean()

    # Advanced Visualization
    st.subheader(f"Average Prices in {neighborhood}")
    st.markdown(f"Displaying results for **{room_type}** room type(s)." if room_type != "All" else "Displaying results for **all room types**.")

    # Interactive Bar Chart
    if not avg_prices.empty:
        fig, ax = plt.subplots()
        avg_prices.plot(kind='bar', color='skyblue', ax=ax)
        ax.set_title(f"Average Prices by Room Type in {neighborhood}", fontsize=16, pad=20)
        ax.set_ylabel("Price ($)", fontsize=12)
        ax.set_xlabel("Room Type", fontsize=12)
        ax.bar_label(ax.containers[0], fmt='${:.2f}', padding=3, fontsize=10)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.tick_params(axis='x', rotation=45)

        st.pyplot(fig)
    else:
        st.info("No data available for the selected filters.")

    # Show Detailed Data Table
    st.subheader("Detailed Data")
    st.markdown("""
    The table below shows detailed information about the listings used to calculate the average prices.  
    Use this to further explore individual listings.
    """)
    st.dataframe(filtered_data[['name', 'room_type', 'price', 'minimum_nights', 'availability_365']])

    # Highlight Key Insights
    st.subheader("Key Insights")
    min_price = filtered_data['price'].min() if not filtered_data.empty else None
    max_price = filtered_data['price'].max() if not filtered_data.empty else None
    avg_price = filtered_data['price'].mean() if not filtered_data.empty else None

    if min_price is not None:
        st.markdown(f"- **Lowest Price**: ${min_price:.2f}")
        st.markdown(f"- **Highest Price**: ${max_price:.2f}")
        st.markdown(f"- **Average Price**: ${avg_price:.2f}")
    else:
        st.info("No price insights available for the selected filters.")

def render_availability_trends():
    st.header("Availability Trends")
    st.markdown("""
    **Description:**  
    This section helps you analyze the seasonal trends in booking availability across Boston neighborhoods.  
    - Select a neighborhood to explore monthly availability.  
    - Use the enhanced line chart to visualize trends dynamically, with insights displayed alongside the chart.  
    """)

    # Neighborhood Selector
    neighborhood = st.selectbox(
        "Select Neighborhood for Availability Trends", 
        listings['neighbourhood'].unique(), 
        help="Choose a neighborhood to analyze average availability trends over the months."
    )

    # Compute Availability Trends
    availability = availability_trends(listings, neighborhood)

    # Ensure the index (months) is integers
    availability.index = availability.index.astype(int)

    # Advanced Visualization
    st.subheader(f"Monthly Availability in {neighborhood}")
    st.markdown(f"The chart below shows the average number of days listings in **{neighborhood}** are available each month.")

    if not availability.empty:
        # Create a more detailed line chart
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(8, 5))
        availability.plot(kind="line", marker="o", color="teal", ax=ax)

        # Customizations
        ax.set_title(f"Monthly Availability Trends for {neighborhood}", fontsize=16, pad=20)
        ax.set_xlabel("Month", fontsize=12)
        ax.set_ylabel("Average Availability (Days)", fontsize=12)
        ax.grid(visible=True, which="major", linestyle="--", linewidth=0.5, alpha=0.7)
        ax.set_xticks(range(1, 13))
        ax.set_xticklabels(
            ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        )
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        # Add Data Labels
        for month, value in availability.items():
            ax.text(month, value + 2, f"{value:.0f}", ha="center", fontsize=10, color="darkblue")

        # Render Plot
        st.pyplot(fig)

        # Key Insights
        st.subheader("Key Insights")
        max_month = int(availability.idxmax())
        max_value = availability.max()
        min_month = int(availability.idxmin())
        min_value = availability.min()

        st.markdown(f"""
        - **Highest Availability**: {max_value:.0f} days in **{calendar.month_name[max_month]}**.
        - **Lowest Availability**: {min_value:.0f} days in **{calendar.month_name[min_month]}**.
        """)
    else:
        st.info("No availability data available for the selected neighborhood.")

    # Data Table
    st.subheader("Detailed Data")
    st.markdown("""
    The table below shows the average availability for each month in the selected neighborhood. Use this for more in-depth analysis.
    """)
    availability_df = availability.reset_index()
    availability_df.columns = ["Month", "Average Availability (Days)"]
    availability_df["Month"] = availability_df["Month"].apply(lambda x: calendar.month_name[int(x)])
    st.table(availability_df)

def render_affordable_listings():
    st.header("Affordable Listings")
    st.markdown("""
    **Description:**  
    Use the slider below to set a maximum price. This section helps you find affordable Airbnb listings in Boston:  
    - View affordable listings on an interactive map.  
    - Hover over the markers to see detailed information about each listing.  
    - Explore the data table for a complete view of the listings within the price range.
    """)

    # User Input: Maximum Price
    max_price = st.slider(
        "Select Maximum Price", 
        50, 1000, 150, 
        step=10, 
        help="Adjust the slider to set the maximum price for affordable listings."
    )

    # Filter Data
    affordable = affordable_listings(listings, max_price)

    # Summary Insights
    st.subheader("Summary Insights")
    if not affordable.empty:
        min_price = affordable['price'].min()
        max_price_in_data = affordable['price'].max()
        avg_price = affordable['price'].mean()

        st.markdown(f"""
        - **Cheapest Listing**: ${min_price:.2f}  
        - **Most Expensive Listing in Range**: ${max_price_in_data:.2f}  
        - **Average Price**: ${avg_price:.2f}
        """)

        # Interactive Map using st.map
        st.subheader("Interactive Map of Affordable Listings")
        st.markdown("""
        The map below shows listings that are below the selected price.""")

        # Display the map with filtered listings
        st.map(affordable[['latitude', 'longitude']])

        # Data Table
        st.subheader("Detailed Data")
        st.markdown("""
        The table below provides detailed information about the affordable listings. Use it to explore and analyze the options.
        """)
        st.dataframe(affordable[['name', 'price', 'room_type', 'minimum_nights', 'availability_365']])
    else:
        st.info("No affordable listings found within the selected price range.")

def render_summary_statistics():
    st.header("Summary Statistics")
    st.markdown("""
    **Description:**  
    This section provides a quick snapshot of the rental market in a specific Boston neighborhood.  
    - Select a neighborhood to view detailed statistics on prices and availability.  
    - Visualize data dynamically through interactive charts.  
    - Explore a table summarizing key metrics.
    """)

    # Neighborhood Selector
    neighborhood = st.selectbox(
        "Select Neighborhood for Summary Statistics", 
        listings['neighbourhood'].unique(), 
        help="Choose a neighborhood to view summary statistics."
    )

    # Calculate Summary Statistics
    stats = summary_statistics(listings, neighborhood)

    # Key Metrics
    st.subheader(f"Key Metrics for {neighborhood}")
    if not stats.empty:
        min_price = stats.loc['min', 'price']
        max_price = stats.loc['max', 'price']
        avg_price = stats.loc['mean', 'price']
        avg_availability = stats.loc['mean', 'availability_365']

        # Display Highlights
        st.markdown(f"""
        - **Minimum Price**: ${min_price:.2f}  
        - **Maximum Price**: ${max_price:.2f}  
        - **Average Price**: ${avg_price:.2f}  
        - **Average Availability**: {avg_availability:.0f} days/year  
        """)

        # Interactive Charts
        st.subheader("Price Distribution")
        st.markdown("""
        The bar chart below shows the distribution of prices in the selected neighborhood.
        """)

        # Price Distribution Chart
        fig, ax = plt.subplots()
        filtered = listings[listings['neighbourhood'] == neighborhood]
        filtered['price'].plot(kind='hist', bins=20, color='teal', edgecolor='black', alpha=0.7, ax=ax)
        ax.set_title(f"Price Distribution in {neighborhood}", fontsize=16, pad=20)
        ax.set_xlabel("Price ($)", fontsize=12)
        ax.set_ylabel("Frequency", fontsize=12)
        ax.grid(visible=True, which='major', linestyle='--', linewidth=0.5, alpha=0.7)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

        st.pyplot(fig)

        # Availability Distribution Chart
        st.subheader("Availability Distribution")
        st.markdown("""
        The chart below shows how availability varies among listings in the selected neighborhood.
        """)
        fig2, ax2 = plt.subplots()
        filtered['availability_365'].plot(kind='hist', bins=20, color='darkorange', edgecolor='black', alpha=0.7, ax=ax2)
        ax2.set_title(f"Availability Distribution in {neighborhood}", fontsize=16, pad=20)
        ax2.set_xlabel("Availability (Days)", fontsize=12)
        ax2.set_ylabel("Frequency", fontsize=12)
        ax2.grid(visible=True, which='major', linestyle='--', linewidth=0.5, alpha=0.7)
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)

        st.pyplot(fig2)

        # Detailed Table
        st.subheader("Detailed Summary Table")
        st.markdown("""
        The table below shows detailed statistics for prices and availability in the selected neighborhood.
        """)
        st.table(stats)

    else:
        st.info("No data available for the selected neighborhood.")

def render_price_comparison():
    st.header("Price Comparison Between Neighborhoods")
    st.markdown("""
    **Description:**  
    Select multiple neighborhoods to compare the average rental prices in each one. This comparison will help you understand the pricing differences across Boston's neighborhoods.
    """)

    # Multiselect for selecting multiple neighborhoods
    selected_neighborhoods = st.multiselect(
        "Select Neighborhoods for Price Comparison", 
        listings['neighbourhood'].unique(),
        default=listings['neighbourhood'].unique()[:3],  # Default to first 3 neighborhoods
        help="Select multiple neighborhoods to compare their average rental prices."
    )

    # Calculate the average price for each selected neighborhood
    if selected_neighborhoods:
        avg_prices = listings[listings['neighbourhood'].isin(selected_neighborhoods)] \
            .groupby('neighbourhood')['price'] \
            .mean() \
            .sort_values(ascending=False)

        # Display the results in a bar chart
        st.subheader("Average Price Comparison")
        st.markdown(f"This chart shows the average rental prices for the selected neighborhoods.")
        
        # Plotting the bar chart
        fig, ax = plt.subplots(figsize=(10, 6))
        avg_prices.plot(kind='bar', color='teal', edgecolor='black', ax=ax)
        ax.set_title("Average Rental Price Comparison", fontsize=16)
        ax.set_ylabel("Average Price ($)", fontsize=12)
        ax.set_xlabel("Neighborhood", fontsize=12)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.tick_params(axis='x', rotation=45)

        # Add labels to the bars
        for p in ax.patches:
            ax.annotate(f"${p.get_height():.2f}", 
                        (p.get_x() + p.get_width() / 2., p.get_height()), 
                        ha='center', va='center', 
                        fontsize=10, color='black', 
                        xytext=(0, 9), textcoords='offset points')

        st.pyplot(fig)

        # Show the average prices in a table as well
        st.subheader("Detailed Price Table")
        st.markdown("Below is a table showing the average prices for the selected neighborhoods.")
        st.table(avg_prices)

    else:
        st.info("Please select at least one neighborhood to compare prices.")

def render_filter_by_reviews():
    st.header("Filter Listings by Number of Reviews")
    st.markdown("""
    **Description:**  
    Use the slider below to filter listings based on the minimum number of reviews.  
    This allows you to focus on more established listings, which may have higher ratings and more customer feedback.
    """)

    # Slider for minimum number of reviews
    min_reviews = st.slider(
        "Select Minimum Number of Reviews", 
        0, 1000, 50,  # Slider range from 0 to 1000, default is 50
        step=10, 
        help="Select the minimum number of reviews for the listings you want to view."
    )

    # Filter listings based on the selected minimum reviews
    filtered_listings = listings[listings['number_of_reviews'] >= min_reviews]

    # Display the filtered listings
    if not filtered_listings.empty:
        st.subheader(f"Listings with at least {min_reviews} reviews")
        
        # Display a summary of the filtered data (e.g., count of listings)
        st.markdown(f"Total Listings: {len(filtered_listings)}")

        # Show the filtered listings on a map
        st.markdown("### Listings on the Map")
        
        # Use st.map to plot the listings based on their latitude and longitude
        st.map(filtered_listings[['latitude', 'longitude']])

        # Display a table with detailed information about the filtered listings
        st.subheader("Detailed Listings Table")
        st.markdown("""
        The table below shows detailed information about the listings that meet the review criteria.
        """)
        st.dataframe(filtered_listings[['name', 'room_type', 'price', 'number_of_reviews', 'availability_365']])
    else:
        st.info(f"No listings found with at least {min_reviews} reviews.")
   
def render_time_series_analysis():
    st.header("Time Series Analysis of Prices")
    st.markdown("""
    **Description:**  
    This feature helps you explore how the rental prices have changed over time in a selected neighborhood.  
    - Choose a neighborhood to analyze the price trends.
    - View the monthly average prices over the years, which can help identify seasonality and market trends.
    """)

    # Neighborhood Selector
    neighborhood = st.selectbox(
        "Select Neighborhood for Time Series Analysis", 
        listings['neighbourhood'].unique(),
        help="Select a neighborhood to explore the time series of rental prices."
    )

    # Date Range Selector (optional: filter by date range)
    st.markdown("""
    **Optional:**  
    You can choose a specific year or time period to focus on, or leave it open to analyze all available data.
    """)

    start_year = st.slider("Start Year", 2010, 2024, 2015, help="Select the start year for your analysis.")
    end_year = st.slider("End Year", 2010, 2024, 2024, help="Select the end year for your analysis.")
    
    # Filter the data based on the selected neighborhood and time range
    filtered_data = listings[
        (listings['neighbourhood'] == neighborhood) &
        (listings['last_review'].dt.year >= start_year) &
        (listings['last_review'].dt.year <= end_year)
    ]

    # Group the data by year and month, calculate average price
    filtered_data['year_month'] = filtered_data['last_review'].dt.to_period('M')
    avg_monthly_prices = filtered_data.groupby('year_month')['price'].mean()

    # Plotting the Time Series
    st.subheader(f"Monthly Average Rental Prices in {neighborhood} ({start_year} - {end_year})")
    st.markdown(f"This chart shows the trend of monthly average prices for the selected neighborhood over the specified time period.")


    fig, ax = plt.subplots(figsize=(10, 6))
    avg_monthly_prices.plot(kind='line', color='teal', marker='o', ax=ax)

    ax.set_title(f"Monthly Average Prices for {neighborhood}", fontsize=16, pad=20)
    ax.set_xlabel("Date", fontsize=12)
    ax.set_ylabel("Average Price ($)", fontsize=12)
    ax.grid(visible=True, which='major', linestyle='--', linewidth=0.5, alpha=0.7)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    st.pyplot(fig)

    # Display the data as a table
    st.subheader("Detailed Time Series Data")
    st.markdown("""
    The table below shows the monthly average prices for the selected neighborhood over the chosen time period.
    """)
    st.table(avg_monthly_prices)

    # Key Insights
    st.subheader("Key Insights")
    if not avg_monthly_prices.empty:
        max_price_month = avg_monthly_prices.idxmax()
        max_price = avg_monthly_prices.max()
        min_price_month = avg_monthly_prices.idxmin()
        min_price = avg_monthly_prices.min()

        st.markdown(f"""
        - **Highest Average Price**: ${max_price:.2f} in **{max_price_month}**.
        - **Lowest Average Price**: ${min_price:.2f} in **{min_price_month}**.
        """)

    else:
        st.info("No price data available for the selected time range and neighborhood.")


# ========== Sidebar and Navigation ========== #
def sidebar_navigation():
    st.sidebar.title("Navigation")
    st.sidebar.markdown("Use the options below to explore different aspects of the Boston Airbnb data.")
    return st.sidebar.radio("Select a feature", [
        "Introduction",
        "Average Rental Prices",
        "Availability Trends",
        "Affordable Listings",
        "Price Comparison Between Neighborhoods",
        "Time Series Analysis of Prices",
        "Filter Listings by Number of Reviews",
        "Summary Statistics",
    ])

# ========== Main Application ========== #
def main():
    app_title()
    selected_feature = sidebar_navigation()

    # Feature-based rendering
    if selected_feature == "Introduction":
        st.image("./data/logo.webp")
        st.markdown("""
        ### How to Use:
        - Navigate through the app using the sidebar.
        - Explore rental prices, availability trends, and affordable listings.
        - Use interactive widgets to customize the visualizations.
        """)
    elif selected_feature == "Average Rental Prices":
        render_average_prices()
    elif selected_feature == "Availability Trends":
        render_availability_trends()
    elif selected_feature == "Affordable Listings":
        render_affordable_listings()
    elif selected_feature == "Summary Statistics":
        render_summary_statistics()
    elif selected_feature == "Price Comparison Between Neighborhoods":
        render_price_comparison()
    elif selected_feature == "Time Series Analysis of Prices":
        render_time_series_analysis()
    elif selected_feature == "Filter Listings by Number of Reviews":
        render_filter_by_reviews()
 
# Run the app
if __name__ == "__main__":
    main()
